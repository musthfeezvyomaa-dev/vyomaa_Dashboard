import React from "react";

type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "default" | "outline" };
export function Button({ className, variant = "default", ...rest }: Props) {
  const base = "px-3 py-2 rounded-xl text-sm font-medium transition";
  const styles =
    variant === "outline"
      ? "border bg-white hover:bg-gray-50"
      : "bg-sky-600 hover:bg-sky-700 text-white";
  return <button className={`${base} ${styles} ${className || ""}`} {...rest} />;
}
